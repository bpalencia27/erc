# Inicialización del paquete de API
"""
Módulos para interactuar con APIs externas
"""
