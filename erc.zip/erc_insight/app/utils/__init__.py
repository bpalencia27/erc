# Inicialización del paquete de utils
"""
Utilidades generales para la aplicación
"""
