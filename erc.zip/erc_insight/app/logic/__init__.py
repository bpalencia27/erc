# Inicialización del paquete de lógica
"""
Módulos para la lógica de negocio de la aplicación
"""
