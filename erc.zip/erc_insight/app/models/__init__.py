"""
Inicialización del paquete de modelos
"""
# Este archivo permite que Python reconozca el directorio 'models' como un paquete
